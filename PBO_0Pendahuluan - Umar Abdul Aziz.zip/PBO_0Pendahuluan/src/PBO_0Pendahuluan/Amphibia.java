/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Amphibia extends Hewan {

    public void utama() {
        System.out.println("Ciri utama yaitu mengalami metamorfosis lengkap yang hanya ada di vertebrata");
    }

    public void jantung() {
        System.out.println("Memiliki jantung yang terdiri dari tiga ruang, satu ventrikel dan dua buah atrium");
    }

    public void reproduksi() {
        System.out.println("Akan bereproduksi dengan bertelur serta pembuahan eksternal");
    }

    public void kulit() {
        System.out.println("Memiliki kulit yang cenderung berlendir");
    }

}
