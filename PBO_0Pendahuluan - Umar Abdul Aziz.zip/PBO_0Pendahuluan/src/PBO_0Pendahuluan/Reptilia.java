/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Reptilia extends Hewan {

    public void utama() {
        System.out.println("Memiliki ciri utama yakni kulit yang bersisik guna melindungi tubuh dari gesekan air, mencegah kehilangan air, dan membantu dalam pergerakan");
    }

    public void nafas() {
        System.out.println("Bernafas melalui paru paru");
    }

    public void tulang() {
        System.out.println("Memiliki tulang belakang yang berfungsi sebagai penopangtubuh dan melindungi sumsum tulang belakang");
    }

    public void cakar() {
        System.out.println("Dan juga memiliki cakar pada kaki mereka guna menggali, memanjat, ataupun menagkap mangsa");
    }
}
