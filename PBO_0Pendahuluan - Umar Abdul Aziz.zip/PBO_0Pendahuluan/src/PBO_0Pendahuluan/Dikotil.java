/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Dikotil extends Tumbuhan {

    public void kepingBiji() {
        System.out.println("Ciri utama memiliki dua kotiledon");
    }

    public void tulangDaun() {
        System.out.println("Memiliki tulang daun yang menyirip atau menjari");
    }

    public void batang() {
        System.out.println("Xilem dan floemnya tersusun dalam suatu lingkaran");
    }

    public void bunga() {
        System.out.println("Bagian perhiasan bunganya terdiri dari 2,4,5 atau kelipatannya");
    }

    public void akar() {
        System.out.println("Sistem akarnya adalah tunggang");
    }

    public void reproduksi() {
        System.out.println("Reproduksinya dengan cara generatif dan vegetatif");
    }

    public void kambium() {
        System.out.println("Batangnya berkambium dan diameternya akan membesar");
    }

    public void stomata() {
        System.out.println("Daunnya memiliki stomata pada permukaan daun yang tersusun secara acak sehingga membentuk urat bercabang");
    }
}
