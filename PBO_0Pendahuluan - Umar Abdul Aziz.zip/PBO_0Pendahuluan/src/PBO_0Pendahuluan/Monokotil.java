/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Monokotil extends Tumbuhan {

    public void kepingBiji() {
        System.out.println("Ciri utama memiliki satu kotiledon");
    }

    public void tulangDaun() {
        System.out.println("Memiliki tulang daun yang sejajar atau melengkung");
    }

    public void batang() {
        System.out.println("Xilem dan floemnya tersebar dibatang");
    }

    public void bunga() {
        System.out.println("Bagian perhiasan bunganya hanya terdiri dari 3 atau kelipatannya");
    }

    public void akar() {
        System.out.println("Sistem akarnya adalah serabut");
    }//

    public void reproduksi() {
        System.out.println("Reproduksinya hanya dengan cara generatif");
    }

    public void kambium() {
        System.out.println("Batangnya tidak berkambium");
    }

    public void stomata() {
        System.out.println("Daunnya memiliki stomata pada kedua sisinya dan tersusun secara teratur sehingga dicirikan oleh urat paralel");
    }
}
