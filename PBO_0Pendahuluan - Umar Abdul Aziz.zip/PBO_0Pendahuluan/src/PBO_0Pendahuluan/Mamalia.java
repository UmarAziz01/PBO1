/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Mamalia extends Hewan {

    public void utama() {
        System.out.println("Ciri utamanya memiliki kelenjar susu");
    }

    public void rambut() {
        System.out.println("Umummnya memiliki rambut ditubuhnya");
    }

    public void tulang() {
        System.out.println("Dia termasuk vertebrata yang menjadikan dia memilki tulang belakang");
    }

    public void jantung() {
        System.out.println("Memiliki jantung yang terdiri dari 4 ruang, dua ventrikel dan dua buah atrium. Sistem peredaran darahnya tertutup dan ganda");
    }
}
