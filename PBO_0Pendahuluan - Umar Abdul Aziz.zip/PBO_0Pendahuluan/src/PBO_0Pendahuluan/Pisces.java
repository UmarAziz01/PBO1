/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO_0Pendahuluan;

/**
 *
 * @author ASUS
 */
public class Pisces extends Hewan {

    public void utama() {
        System.out.println("Bernafas memakai insang");
    }

    public void sisik() {
        System.out.println("Memiliki sisik yang berfungsi sebagai pelindungan tubuh dari gesekan, infeksi, dan membantu mengurangi hambatan saat berenang");
    }

    public void gerak() {
        System.out.println("Bergerak dengan alat gerak berupa sirip");
    }

    public void khusus() {
        System.out.println("Memilki gurat sisi yang berguba untuk merasakan perubahan tekanan air");
    }
}
